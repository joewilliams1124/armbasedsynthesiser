#ifndef __Buttons_H
#define __Buttons_H

#include "stm32f407xx.h"

extern uint32_t BTN_Get(void);
extern void BTN_Init(void);
	
#endif
