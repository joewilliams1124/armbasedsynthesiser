#ifndef __Presets_H
#define __Presets_H

#include "config.h"

void presetInit(void);

void selectSound(int n);

void selectPreset(int n);

void presetsConnect(void);

#endif

