#ifndef __SYNTH_H
#define __SYNTH_H

void synthInit(void);
float synthTic(void);

#endif
