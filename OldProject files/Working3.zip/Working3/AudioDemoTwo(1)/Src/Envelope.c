#include "stm32f4xx_hal.h"
#include "envelope.h"
#include <math.h>

envelope 		env1;
envelope 		env2;
envelope 		env3;
envelope 		env4;
envelope 		env5;
envelope 		env6;

int trigger = 0;


void envInit(envelope *env){
	env->aTime = 1;
	env->aLevel = 1;
	env->dTime = 1;
	env->dLevel = 0.5;
	env->sTime = 1;
	env->sLevel = 0.5;
	env->rTime = 1;
	env->rLevel = 0;
	env->State = 'a';
	env->Count = 0;
	env->Out = 0;
	envCalc(env);
}

void envSet(envelope *env, float aTime, float aLevel, float dTime, float dLevel, float sTime, float sLevel, float rTime, float rLevel){
	env->aTime = aTime;
	env->aLevel = aLevel;
	env->dTime = dTime;
	env->dLevel = dLevel;
	env->sTime = sTime;
	env->sLevel = sLevel;
	env->rTime = rTime;
	env->rLevel = rLevel;
	envCalc(env);
}

void envCalc(envelope *env){
	env->aTime = env->aTime * 44100;
	env->dTime = env->dTime * 44100;
	env->sTime = env->sTime * 44100;
	env->rTime = env->rTime * 44100;
	
	env->p1Time = env->aTime;
	env->p2Time = env->p1Time + env->dTime;
	env->p3Time = env->p2Time + env->sTime;
	env->p4Time = env->p3Time + env->rTime;
}

void envState(envelope *env, int trigger){
	if (env->Count < env->p1Time){
		env->State = 'a';
		//Attack//
	}
	if (env->Count >= env->p1Time){
		env->State = 'd';
		//Decay//
	}
	if (env->Count >= env->p2Time){
		env->State = 's';
		//Sustain//
	}
	if ((env->Count >= env->p3Time) && (trigger == 1)) {
		env->Count = env->Count - 1;
		env->State = 'h';
		//Hold on//
	}
	if ((env->Count >= env->p3Time) && (trigger == 0)){
		env->State = 'r';	
		//Release//
	}
	if (env->Count >= (env->p4Time + 2)){
		env->Count = env->Count - 1; //So the counter doesn't keep going//
		env->Out = 0;
		env->State = 'h';
		//Hold off//
	}
}

float envOutput(envelope *env){
	switch (env->State){
		case 'a': 
			env->Out = env->Out + (env->aLevel / env->aTime);
		break;
		
		case 'd':
			env->Out = env->Out + ((env->dLevel - env->aLevel) / env->dTime);
		break;
		
		case 's':
			env->Out = env->Out + ((env->sLevel - env->dLevel) / env->sTime);
		break;
		
		case 'h':
			//This is the hold state the output staty//
		break;
		
		case 'r':
			env->Out = env->Out + ((env->rLevel - env->sLevel) / env->rTime);
		break;
	}
	
	env->Count = env->Count + 1;
	
	return env->Out;
}

void envReset(){
	env1.Count = 0;
	env2.Count = 0;
	env3.Count = 0;
	env4.Count = 0;
	env5.Count = 0;
	env6.Count = 0;
}

//MIDI NOTE ON SHOULD CHANGE TRIGGER TO 1 & reset the counter//
//MIDI NOTE OFF SHOULD CHANGE THE TRIGGER TO 0//
//Might need to change this to write into an array then read back from it, this will speed up processing//

