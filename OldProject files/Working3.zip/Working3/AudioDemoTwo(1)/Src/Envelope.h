#ifndef __envelope_H
#define __envelope_H

//#include "stm32f4xx_hal.h"

typedef struct
{
	float 	aTime;	
	float		aLevel;	
	float 	dTime;	
	float 	dLevel;	
	float 	sTime;
	float 	sLevel;
	float 	rTime;
	float 	rLevel;
	float 	p1Time;
	float 	p2Time;
	float 	p3Time;
	float 	p4Time;
	float 	Count;
	char 		State;
	float   Out;
} envelope;

void envInit(envelope *env);

void envState(envelope *env, int trigger);

void envCalc(envelope *env);

float envOutput(envelope *env);

void envSet(envelope *env, float aTime, float aLevel, float dTime, float dLevel, float sTime, float sLevel, float rTime, float rLevel);

void envReset(void);

#endif

