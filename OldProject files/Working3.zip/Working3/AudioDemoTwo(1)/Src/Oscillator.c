#include "stm32f4xx_hal.h"
#include "oscillator.h"
#include <math.h>

#define PBSIZE 16384
#define SINELOOKUPSIZE 8192
#define PI 3.141592653589793
int16_t SineTable[PBSIZE];


oscillator 		osc1;
oscillator 		osc2;
oscillator 		osc3;
oscillator		osc4;
oscillator 		osc5;
oscillator		osc6;

void oscInit(oscillator *osc){
	osc->amp = 9;
	osc->freq = 261.6;
	osc->phase = 0;
	osc->out = 0;
	osc->phaseInc = 1;
	generateSineTable();
	oscSetPhaseInc(osc);
}

void oscSetFreq(oscillator *osc, float f){
	osc->freq = f;
	oscSetPhaseInc(osc);
}

void oscSetAmp(oscillator *osc, float a){
	osc->amp = a;
}


void oscSetPhaseInc(oscillator *osc){
	float phaseInc = SINELOOKUPSIZE * osc->freq / 44100;
	osc->phaseInc = phaseInc;
}

float oscOutput(oscillator *osc){
	if (osc->phase > SINELOOKUPSIZE) osc->phase -= SINELOOKUPSIZE;
	osc->phase += osc->phaseInc;
	osc->out = SineTable[(uint16_t)(osc->phase)] * osc->amp;
	return osc->out;
}


///// Set up the sine look-up table:
void generateSineTable(){
	for (int i = 0; i <= SINELOOKUPSIZE; i++) {
		float q = 32760 * sin(i * 2.0 * PI / SINELOOKUPSIZE);
		SineTable[i] = (int16_t)q;
	}
}
	
