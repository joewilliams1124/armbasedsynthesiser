//THIS WILL HAVE A FUNCTION WHICH OUTPUTS THE CORRECT SYNTH AUDIO//
//IT'LL ALSO HAVE SOME ERROR HANDLING AND BOOT UP PROTOCOL//
//IT'LL CALL THE FUNCTIONS FROM PRESET MANAGER + OUTPUT MIXER//
#include "PresetManager.h"
#include "Control.h"

float noteNum = 261.62;

void synthInit(){
	presetInit();
	//some lights n LCD stuff//
}

void synthPreset(int patch){
	switch (patch) {
		case 1: presetOneVal();
		//some lights n LCD stuff//
	break;
	}
}	

float synthTrigger(){
	float out = triggerControl();
	return out;
	//Do other stuff//
}

