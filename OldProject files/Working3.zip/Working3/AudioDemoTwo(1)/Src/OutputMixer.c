#include <math.h>
#include "OutputMixer.h"

Mixer 		Mixer1;

uint16_t castOutput(float value, Mixer * Mixer1){
	value = value / 10;
	Mixer1->outpt = (uint16_t)((int32_t)(value));
	return Mixer1->outpt;
}

