#ifndef __PRESETMANAGER_H
#define __PRESETMANAGER_H

#include "envelope.h"
#include "operator.h"
#include "oscillator.h"

void presetInit(void);

void presetOneVal(void);

float presetOneAlg(int trigger, float freq);

float presetTwoAlg(int trigger, float freq);

float presetThreeAlg(int trigger, float freq);

float presetFourAlg(int trigger, float freq);

void envReset(void);

#endif
