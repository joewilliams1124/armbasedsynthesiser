#ifndef __operator_H
#define __operator_H

#include "stm32f4xx_hal.h"
#include <math.h>
#include "oscillator.h"
#include "envelope.h"

typedef struct
{
	float 	modIndex;	// should be <= 1 for normal sound output
	float	  modAmount;	// Hertz
	float 	out;	// output sample
} operator;


void opInit(operator * op, oscillator * osc, envelope * env);
	
float opOutput(float freq, operator * op, oscillator * osc, envelope * env);

void opSet(operator * op, float modIndex, float modAmount);

float opTrigger(int trigger,float freq, operator * op, oscillator * osc, envelope * env);

#endif


