#include "PresetManager.h"
#include "OutputMixer.h"
#include "Control.h"
#include "noteTable.h"
#include "Buttons.h"
#include "Envelope.h"

extern Mixer	        Mixer1;

float out;
float freq;
int alg = 4;
int trig = 1;
float vel = 1;
int note = 30;
uint32_t btnNow = 0;
uint32_t btnPrev = 0;

//Assign to trigger control from midi, e.g set local variable for freq and velocity//
//You'll need to remove these from synth.c ^^//

//The trigger is an int as It may be a helpful way of doing polyphony//

int btnTrigger(void){ //THIS DOESN'T WORK PROPERLY, WORTH MODELING ON MATLAB WHEN DOING MIDI//
	btnNow = BTN_Get();
	if (btnNow == 0 && btnPrev == 0){
		trig = 0;
		envReset();
	}
	if (btnNow == 1 && btnPrev == 0){
		trig = 1;
		envReset();
	}
	if (btnNow == 1 && btnPrev == 1){
		trig = 1;
	}
	if (btnNow == 0 && btnPrev == 1){
		trig = 0;
	}	
	btnPrev = btnNow;
	return trig;
}

float triggerControl(){
	trig = 0;
	switch (alg)
	{
		case 1: 
			 freq = noteToFreq(note);
			 out = presetOneAlg(trig,freq);
			break;
		case 2:
			freq = noteToFreq(note);
			out = presetTwoAlg(trig,freq);
			break;
		case 3: 
			freq = noteToFreq(note);
			out = presetThreeAlg(trig,freq);
		case 4:
			freq = noteToFreq(note);
		  out = presetFourAlg(trig,freq);		
		default:
			break;
	}
	out = out * vel;
	out = castOutput(out,&Mixer1);
	return out;
}

void switchAlg(void){ //TODO
	//Change algorithm when button is released//
}

