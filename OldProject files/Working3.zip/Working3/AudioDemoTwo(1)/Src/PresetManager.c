#include "envelope.h"
#include "operator.h"
#include "oscillator.h"
#include "PresetManager.h"

extern oscillator 		osc1 ;
extern oscillator 		osc2 ;
extern oscillator 		osc3 ;
extern oscillator 		osc4 ;
extern oscillator 		osc5 ;
extern oscillator			osc6 ;

extern envelope 			env1;
extern envelope 			env2;
extern envelope 			env3;
extern envelope 			env4;
extern envelope 			env5;
extern envelope 			env6;

extern operator        op1;
extern operator        op2;
extern operator        op3;
extern operator        op4;
extern operator        op5;
extern operator        op6;

float car1;
float car2;
float car3;
float car4;
float mod1;
float mod2;
float mod3;
float mod4;

void presetInit(){
	opInit(&op1,&osc1,&env1);
	opInit(&op2,&osc2,&env2);
	opInit(&op3,&osc3,&env3);
	opInit(&op4,&osc4,&env4);
	opInit(&op5,&osc5,&env5);
	opInit(&op6,&osc6,&env6);
}

void presetOneVal(void){
	//All outputted OPs ModAmount should = 1//
	opSet(&op1,3.5,0.015);
	envSet(&env1,0.1,0.4,0.1,0.2,0.2,0.1,1,0);
	opSet(&op2,1,0.9);
	envSet(&env2,0.2,0.3,0.1,0.7,0.5,0.2,4,0);
	opSet(&op3,1.2,0.1);
	envSet(&env3,0.01,0.2,0.2,0,0.1,0.5,2,0);
	opSet(&op4,4,0.12);
	envSet(&env4,1,0.2,1,0.9,0.5,0.7,3,0);
}

float presetFourAlg(int trigger, float freq){
	mod1 = opTrigger(trigger, freq, &op1, &osc1, &env1);
  car1 = opTrigger(trigger, (freq + mod1), &op2,&osc2,&env2);
  mod2 = opTrigger(trigger, freq, &op3,&osc3,&env3);
	car2 = opTrigger(trigger, (freq + mod2), &op4,&osc4,&env4);
	car3 = opTrigger(trigger, freq, &op5,&osc5,&env5);
	return car1 + car2 + car3;
}

float presetTwoAlg(int trigger, float freq){
	mod1 = opTrigger(trigger, freq, &op1,&osc1,&env1);
  car1 = opTrigger(trigger, freq + mod1, &op2,&osc2,&env2);
	car2 = opTrigger(trigger, freq, &op4,&osc4,&env4);
	car3 = opTrigger(trigger, freq, &op5,&osc5,&env5);
	return car1 + car2 + car3;
}

float presetThreeAlg(int trigger, float freq){
	mod1 = opTrigger(trigger, freq, &op1,&osc1,&env1);
  car1 = opTrigger(trigger, freq + mod1, &op2,&osc2,&env2);
	car2 = opTrigger(trigger, freq + mod1, &op3,&osc3,&env3);
	return car1 + car2;
}

float presetOneAlg(int trigger, float freq){
  car1 = opTrigger(trigger, freq, &op2,&osc2,&env2);
	return car1;
}


