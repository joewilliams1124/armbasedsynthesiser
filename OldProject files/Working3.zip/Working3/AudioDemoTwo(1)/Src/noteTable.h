#ifndef __NOTETABLE_H
#define __NOTETABLE_H

extern const float freqOfNote[];
float noteToFreq(int note);

#endif
