#ifndef __CONTROL_H
#define __CONTROL_H

#include "envelope.h"
#include "operator.h"
#include "oscillator.h"

float triggerControl(void);
int btnTrigger(void);

#endif
