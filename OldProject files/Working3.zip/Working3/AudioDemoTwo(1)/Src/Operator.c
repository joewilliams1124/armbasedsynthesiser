#include "envelope.h"
#include "oscillator.h"
#include "operator.h"

operator 		op1;
operator 		op2;
operator 		op3;
operator		op4;
operator 		op5;
operator		op6;
operator 		LFO;
operator		VIB;

void opInit(operator * op, oscillator * osc, envelope * env){
	op->modIndex = 1;
	op->modAmount = 0;
	oscInit(osc);
	envInit(env);
}

void opSet(operator * op, float modIndex, float modAmount){
	op->modIndex = modIndex;
	op->modAmount = modAmount;
}

float opOutput(float freq, operator * op, oscillator * osc, envelope * env){
	freq = freq * op->modIndex;
	oscSetFreq(osc,freq);
	op->out = oscOutput(osc) * envOutput(env);
	op->out = op->out * op->modAmount;
	return op->out;
}

float opTrigger(int trigger, float freq, operator * op, oscillator * osc, envelope * env){
	
	float out;
	
	if (trigger == 1){
	envState(env,1);
	out = opOutput(freq,op,osc,env);
	}
	if (trigger == 0){
	envState(env,0);
	out = opOutput(freq,op,osc,env);	
	}
	//DONE LIKE THIS SO WE CAN HAVE MORE STATES FOR VOX ALLOCATION//
	return out;
}

