#ifndef __PRESETMANAGER_H
#define __PRESETMANAGER_H

#include "envelope.h"
#include "operator.h"
#include "oscillator.h"
#include "noteTable.h"

void presetInit(void);

void preset1(void);

void preset2(void);

void preset3(void);

void bigVal(void);

float bigAlg(int trigger, int note);

void selectPreset(int n);

void algsInit(void);

float algTrig(int trigger, int note, int alg);

#endif
