#include "Control.h"
#include "config.h"

extern envelope 			envs[OPERATORS];

extern operator        ops[OPERATORS];

extern MIDImessage    MIDI;

extern Mixer 		Mixer1;

float scale127(int MIDIvalue, float max){
	float scaling =  max / 127;
	float value = (float) MIDIvalue * scaling;
	return value;
}

void MIDIConnect(void){
	Mixer1.scale = (scale127(MIDI.velocity, 1) * scale127(MIDI.ccData[10], 1));
	
	//ops[1].modIndex = scale127(MIDI.ccData[11],3);
	//ops[2].modIndex = scale127(MIDI.ccData[11],3);
	//ops[3].modIndex = scale127(MIDI.ccData[11],3);
	
	//ops[1].modAmount = scale127(MIDI.ccData[14], 0.25);
	//ops[2].modAmount = scale127(MIDI.ccData[15], 0.25);
	//ops[3].modAmount = scale127(MIDI.ccData[16], 0.25);
	//ops[4].modAmount = scale127(MIDI.ccData[17], 0.25);
	
	//ops[1].detune = scale127(MIDI.ccData[18], 100);
	//ops[2].detune = scale127(MIDI.ccData[19], 100);
	//ops[3].detune = scale127(MIDI.ccData[20], 100);
	//ops[4].detune = scale127(MIDI.ccData[21], 100);
}

//This takes all inputs and makes them into meaningful functions//

//Takes the velocity value from an incoming MIDI message, (note off messages have 0 velocity).
//Turns to a trigger for the preset manager to pass to the envelopes//
//If the value is non zero this represents a new 'note on' message//
//In this case the envelopes should be reset//
//This should be called in the interupt handler, so it's only called when the value changes//

