#ifndef __oscillator_H
#define __oscillator_H

#include "stm32f4xx_hal.h"
#include <math.h>

typedef struct
{
	float 	amp;	// should be <= 1 for normal sound output
	float	  freq;	// Hertz
	float   phase;	// radians
	float 	out;	// output sample
	float 	prevOut;
	float 	phaseInc;
} oscillator;

/// THEN ALL THE FUNCTIONS //

void oscInit(oscillator * osc);

void oscSetFreq(oscillator * osc, float freq);

void oscSetAmp(oscillator * osc, float amp);

void oscSetPhaseInc(oscillator * osc);

float oscOutput(oscillator * osc);

void generateSineTable(void);


#endif
