//THIS WILL HAVE A FUNCTION WHICH OUTPUTS THE CORRECT SYNTH AUDIO//
//IT'LL ALSO HAVE SOME ERROR HANDLING AND BOOT UP PROTOCOL//
//IT'LL CALL THE FUNCTIONS FROM PRESET MANAGER + OUTPUT MIXER//
#include "PresetManager.h"
#include "OutputMixer.h"
#include "MIDI.h"
#include "Control.h"

extern Mixer	        Mixer1;
extern MIDImessage		MIDI;

int patch = 1;

//Top level controls for model//

void synthInit(){
	presetInit();
	//Do other stuff from UIFeedback//
}

void synthPreset(int patch){
		 //selectPreset(2);
		preset3();
}	 

float synthTrigger(){

	//int vox = getVox();
	
	float out = algTrig(MIDI.trigger, MIDI.noteNum, 30);
	
	//float out = presetThreeAlg(0,35);
	//float out = bigAlg(1,40);
	
	MIDIConnect();
	out = castOutput(out,&Mixer1);
	
	return out;
	
	//Do other stuff from UIFeedback//
}


