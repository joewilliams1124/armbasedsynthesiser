#include "PresetManager.h"
#include <stdio.h>
#include "config.h"

//Can I simpy use this class to define all the extra voices//
//Or do it similarly in a different class//

//This class instanciates all the oscillators, envelopes and operators and defines how they interconnect.//

extern envelope 			envs[OPERATORS];

extern operator        ops[OPERATORS];

//These are internal signals used to simplify the programming of the presets/algorithms

float freq;
float sig[OPERATORS];
float fdbk = 0.01;
float (*algs[33])(int trigger, int note);
void (*presets[5])();

//Initialise all the operators. 
void presetInit(){
	opConnect();
	algsInit();
	for (int i = 0; i < OPERATORS; i ++){
	opInit(i);
	}
}

// I THINK IT'S WORTH SETTING THE ENV IN THE ALG //

//Initalise all parameter values
void preset1(void){
	//All outputted OPs ModAmount should = 1//
	opSet(1,1,0.3);
	envSet(&envs[1],0.1,0.4,0.1,0.2,0.2,0.5,1,0);
	opSet(2,1.3,0.3);
	envSet(&envs[2],0.2,0.3,0.1,0.7,0.5,0.5,1,0);
	opSet(3,1.5,0.3);
	envSet(&envs[3],0.01,0.2,0.2,0.5,0.5,0.5,1,0);
	opSet(4,4,0.3);
	envSet(&envs[4],1,0.2,1,0.9,0.5,0.7,3,0);
	//opSet(5,2.7,0.3);
	//envSet(&envs[5],0.01,0.2,1,0.9,0.5,0.7,3,0);
	ops[3].detune = 1;
	//voxConnect();
}

//Initalise all parameter values
void preset2(void){
	//All outputted OPs ModAmount should = 1//
	opSet(1,1,0.16);
	envSet(&envs[1],0.3,1,1,1,1,1,1,0);
	opSet(2,1.5,0.16);
	envSet(&envs[2],0.3,1,2,1,1,1,1,0);
	opSet(3,2,0.16);
	envSet(&envs[3],0.3,1,3,1,1,1,1,0);
	opSet(4,2.5,0.16);
	envSet(&envs[4],0.3,1,4,1,1,1,1,0);
	//opSet(5,3,0.15);
	//envSet(&envs[5],0.1,1,5,1,1,1,1,1);
	//opSet(6,3.5,0.15);
	//envSet(&envs[6],0.1,1,6,1,1,1,1,1);
	//voxConnect();
}
void preset3(void){
	
	opSet(1,1.01,0.16);
	opSet(2,1,0.16);
	opSet(3,0.999,0.16);
	opSet(4,3.01,0.16);
	opSet(5,2,0.16);
	opSet(6,3,0.16);
	
	envSet(&envs[1],0.1,1,0.1,1,0.1,1,0.3,0);
	envSet(&envs[2],0.1,1,0.1,1,0.1,1,0.3,0);
	envSet(&envs[3],0.1,1,0.1,1,0.1,1,0.2,0);
	envSet(&envs[4],0.1,1,0.1,0.7,0.1,1,0.1,0);
	envSet(&envs[5],0.1,1,0.1,1,0.1,1,0.2,0);
	envSet(&envs[6],0.1,1,0.2,0,0,0,0,0);
}
//https://cboard.cprogramming.com/c-programming/128162-array-functions.html

float algTrig(int trigger, int note, int alg){
	freq = noteToFreq(note);
	float out = algs[alg](trigger,freq);
	return out;
}

void selectPreset(int n){
	presets[n]();
}

float alg1(int trigger, int note){
	//DONE
	sig[2] = opTrigger(trigger, freq, 2);
	sig[1] = opTrigger(trigger, freq + sig[2], 1);
	
	sig[6] = opTrigger(trigger, freq + (sig[6] * fdbk), 1);
	sig[5] = opTrigger(trigger, freq + sig[6], 5);
	sig[4] = opTrigger(trigger, freq + sig[5], 4);
	sig[3] = opTrigger(trigger, freq + sig[4], 3);
	
	return sig[1] + sig[3];
}
float alg2(int trigger, int note){
	//DONE
	sig[2] = opTrigger(trigger, freq + (sig[2] * fdbk), 2);
	sig[1] = opTrigger(trigger, freq + sig[2], 1);
	
	sig[6] = opTrigger(trigger, freq + sig[6], 6);
	sig[5] = opTrigger(trigger, freq + sig[6], 5);
	sig[4] = opTrigger(trigger, freq + sig[5], 4);
	sig[3] = opTrigger(trigger, freq + sig[4], 3);
	
	return sig[1] + sig[3];
}
float alg3(int trigger, int note){
	//DONE
	sig[3] = opTrigger(trigger, freq, 3);
	sig[2] = opTrigger(trigger, freq + sig[3], 2);
	sig[1] = opTrigger(trigger, freq + sig[2], 1);
	
	sig[6] = opTrigger(trigger, freq + (sig[6] * fdbk), 3);
	sig[5] = opTrigger(trigger, freq + sig[6], 2);
	sig[4] = opTrigger(trigger, freq + sig[5], 1);
	
	
	return sig[1] + sig[4];
	
}
float alg4(int trigger, int note){
	//DONE
	sig[3] = opTrigger(trigger, freq, 3);
	sig[2] = opTrigger(trigger, freq + sig[3], 2);
	sig[1] = opTrigger(trigger, freq + sig[2], 1);
	
	sig[6] = opTrigger(trigger, freq + (sig[4] * fdbk), 3);
	sig[5] = opTrigger(trigger, freq + sig[6], 2);
	sig[4] = opTrigger(trigger, freq + sig[5], 1);
	
	return sig[1] + sig[4];
}
float alg5(int trigger, int note){
	//DONE
	sig[2] = opTrigger(trigger, freq, 2);
	sig[1] = opTrigger(trigger, freq + sig[2], 1);
	
	sig[4] = opTrigger(trigger, freq, 4);
	sig[3] = opTrigger(trigger, freq + sig[4], 3);
	
	sig[6] = opTrigger(trigger, freq + (sig[6] * fdbk), 6);
	sig[5] = opTrigger(trigger, freq + sig[6], 5);
	
	return sig[5] + sig[3] + sig[1];
}
float alg6(int trigger, int note){
	//DONE
	sig[2] = opTrigger(trigger, freq, 2);
	sig[1] = opTrigger(trigger, freq + sig[2], 1);
	
	sig[4] = opTrigger(trigger, freq, 4);
	sig[3] = opTrigger(trigger, freq + sig[4], 3);
	
	sig[6] = opTrigger(trigger, freq + (sig[5] * fdbk), 6);
	sig[5] = opTrigger(trigger, freq + sig[6], 5);
	
	return sig[5] + sig[3] + sig[1];
}
float alg7(int trigger, int note){
	sig[2] = opTrigger(trigger, freq, 2);
	sig[1] = opTrigger(trigger, freq + sig[2], 1);
	
	sig[6] = opTrigger(trigger, freq + (fdbk * sig[6]), 6); 
	sig[5] = opTrigger(trigger, freq, 5);
	sig[4] = opTrigger(trigger, freq, 4);
	sig[3] = opTrigger(trigger, freq + sig[4] + sig[5], 3);
		//DONE
	return sig[1] + sig[3];
}
float alg8(int trigger, int note){
	
	sig[2] = opTrigger(trigger, freq, 2);
	sig[1] = opTrigger(trigger, freq + sig[1], 1);
	
	sig[6] = opTrigger(trigger, freq, 6); 
	sig[5] = opTrigger(trigger, freq + sig[6], 5);
	sig[4] = opTrigger(trigger, freq + (fdbk * sig[4]), 4);
	sig[3] = opTrigger(trigger, freq + sig[5] + sig[4], 3);
		//DONE
	//THIS IS A TRICKY ONE//
	return sig[1] + sig[3];
}
float alg9(int trigger, int note){
	
	sig[2] = opTrigger(trigger, freq + (fdbk * sig[2]), 2);
	sig[1] = opTrigger(trigger, freq + sig[2], 1);
	
	sig[6] = opTrigger(trigger, freq, 6); 
	sig[5] = opTrigger(trigger, freq + sig[6], 5);
	sig[4] = opTrigger(trigger, freq, 4);
	sig[3] = opTrigger(trigger, freq + sig[4] + sig[5], 3);
		//DONE
	return sig[1] + sig[3];
}
float alg10(int trigger, int note){
	
	sig[3] = opTrigger(trigger, freq + (sig[3] * fdbk), 3);
	sig[2] = opTrigger(trigger, freq + sig[3], 2);
	sig[1] = opTrigger(trigger, freq + sig[2], 1);
	
	sig[6] = opTrigger(trigger, freq, 6);
	sig[5] = opTrigger(trigger, freq, 5);
	sig[4] = opTrigger(trigger, freq + sig[6] + sig[5], 4);
	//DONE
	return sig[1] + sig[4];
}
float alg11(int trigger, int note){
	
	sig[3] = opTrigger(trigger, freq + (sig[3] * fdbk), 3);
	sig[2] = opTrigger(trigger, freq + sig[3], 2);
	sig[1] = opTrigger(trigger, freq + sig[2], 1);
	
	sig[6] = opTrigger(trigger, freq + (sig[6] * fdbk), 6);
	sig[5] = opTrigger(trigger, freq, 5);
	sig[4] = opTrigger(trigger, freq + sig[5] + sig[6], 4);
		//DONE
	return sig[1] + sig[4];
}
float alg12(int trigger, int note){
	
	sig[2] = opTrigger(trigger, freq + (sig[2] * fdbk), 2);
	sig[1] = opTrigger(trigger, freq + sig[2], 1);
	
	sig[4] = opTrigger(trigger, freq, 4);
	sig[5] = opTrigger(trigger, freq, 5);
	sig[6] = opTrigger(trigger, freq, 6);
	sig[3] = opTrigger(trigger, freq + sig[4] + sig[5] + sig[6], 3);
		//DONE
	return sig[1] + sig[3];
}
float alg13(int trigger, int note){
	
	sig[2] = opTrigger(trigger, freq, 2);
	sig[1] = opTrigger(trigger, freq + sig[2], 1);
	
	sig[4] = opTrigger(trigger, freq, 4);
	sig[5] = opTrigger(trigger, freq, 5);
	sig[6] = opTrigger(trigger, freq + (sig[6] * fdbk), 6);
	sig[3] = opTrigger(trigger, freq + sig[4] + sig[5] + sig[6], 3);
	//DONE
	return sig[1] + sig[3];
}
float alg14(int trigger, int note){
	
	sig[2] = opTrigger(trigger, freq, 2);
	sig[1] = opTrigger(trigger, freq + sig[2], 1);
	
	sig[6] = opTrigger(trigger, freq + (sig[6] * fdbk), 6);
	sig[5] = opTrigger(trigger, freq, 5);
	sig[4] = opTrigger(trigger, freq + sig[5] + sig[6], 4);
	sig[3] = opTrigger(trigger, freq + sig[4], 3);
	//DONE
	return sig[1] + sig[3];
}
float alg15(int trigger, int note){
	
	sig[2] = opTrigger(trigger, freq + (fdbk * sig[2]), 2);
	sig[1] = opTrigger(trigger, freq + sig[2], 1);
	
	sig[6] = opTrigger(trigger, freq, 6);
	sig[5] = opTrigger(trigger, freq, 5);
	sig[4] = opTrigger(trigger, freq + sig[5] + sig[6], 4);
	sig[3] = opTrigger(trigger, freq + sig[4], 3);
	//DONE
	return sig[1] + sig[3];
}
float alg16(int trigger, int note){
	
	sig[2] = opTrigger(trigger, freq, 2);
	
	sig[4] = opTrigger(trigger, freq, 4);
	sig[3] = opTrigger(trigger, freq + sig[4], 3);
	
	sig[6] = opTrigger(trigger, freq + (fdbk * sig[6]), 6);
	sig[5] = opTrigger(trigger, freq + sig[6], 5);
	
	sig[1] = opTrigger(trigger, freq + sig[2] + sig[3] + sig[5], 1);
	//DONE
	return sig[1];
	
}
float alg17(int trigger, int note){
	
	sig[2] = opTrigger(trigger, freq + (fdbk * sig[2]), 2);
	
	sig[4] = opTrigger(trigger, freq, 4);
	sig[3] = opTrigger(trigger, freq + sig[4], 3);
	
	sig[6] = opTrigger(trigger, freq, 6);
	sig[5] = opTrigger(trigger, freq + sig[6], 5);
	
	sig[1] = opTrigger(trigger, freq + sig[2] + sig[3] + sig[5], 1);
	//DONE
	return sig[1];
	
}
float alg18(int trigger, int note){
	
	sig[2] = opTrigger(trigger, freq, 2);
	
	sig[3] = opTrigger(trigger, freq + (fdbk * sig[2]), 3);
	
	sig[6] = opTrigger(trigger, freq, 6);
	sig[5] = opTrigger(trigger, freq + sig[6], 5);
	sig[4] = opTrigger(trigger, freq + sig[5], 4);
	
	sig[1] = opTrigger(trigger, freq + sig[2] + sig[3] + sig[4], 1);
	
	return sig[1];
}
float alg19(int trigger, int note){
	
	sig[3] = opTrigger(trigger, freq, 3);
	sig[2] = opTrigger(trigger, freq + sig[3], 2);
	sig[1] = opTrigger(trigger, freq + sig[1], 1);
	
	sig[6] = opTrigger(trigger, freq + (sig[6] * fdbk), 6);
	sig[4] = opTrigger(trigger, freq + sig[6], 4);
	sig[5] = opTrigger(trigger, freq + sig[6], 5);
	//DONE
	return sig[1] + sig[4] + sig[5];
}

float alg20(int trigger, int note){
	
	sig[1] = opTrigger(trigger, freq + sig[3], 1);
	sig[2] = opTrigger(trigger, freq + sig[3], 2);
	sig[3] = opTrigger(trigger, freq + (fdbk * sig[3]), 3);
	sig[4] = opTrigger(trigger, freq + sig[5] + sig[6], 4);
	sig[5] = opTrigger(trigger, freq, 5);
	sig[6] = opTrigger(trigger, freq, 6);
	
	return sig[1] + sig[2] + sig[4];
}
float alg21(int trigger, int note){
	
	sig[1] = opTrigger(trigger, freq + sig[3], 1);
	sig[2] = opTrigger(trigger, freq + sig[3], 2);
	sig[3] = opTrigger(trigger, freq + (fdbk * sig[3]), 3);
	sig[4] = opTrigger(trigger, freq + sig[6], 4);
	sig[5] = opTrigger(trigger, freq + sig[6], 5);
	sig[6] = opTrigger(trigger, freq, 6);
	//DONE
	return sig[1] + sig[2] + sig[3] + sig[4] + sig[5];
}
float alg22(int trigger, int note){
	
	sig[1] = opTrigger(trigger, freq + sig[2], 1);
	sig[2] = opTrigger(trigger, freq, 2);
	sig[3] = opTrigger(trigger, freq + sig[6], 3);
	sig[4] = opTrigger(trigger, freq + sig[6], 4);
	sig[5] = opTrigger(trigger, freq + sig[6], 5);
	sig[6] = opTrigger(trigger, freq + (fdbk* sig[6]), 6);
	//DONE
	return sig[1] + sig[3] + sig[4] + sig[5];
}
float alg23(int trigger, int note){
	
	sig[1] = opTrigger(trigger, freq, 1);
	sig[2] = opTrigger(trigger, freq, 2);
	sig[3] = opTrigger(trigger, freq, 3);
	sig[4] = opTrigger(trigger, freq, 4);
	sig[5] = opTrigger(trigger, freq, 5);
	sig[6] = opTrigger(trigger, freq, 6);
	//DONE
	return sig[1] + sig[2] + sig[4] + sig[5];
}
float alg24(int trigger, int note){
	
	sig[1] = opTrigger(trigger, freq, 1);
	sig[2] = opTrigger(trigger, freq, 2);
	sig[3] = opTrigger(trigger, freq + sig[6], 3);
	sig[4] = opTrigger(trigger, freq + sig[6], 4);
	sig[5] = opTrigger(trigger, freq + sig[6], 5);
	sig[6] = opTrigger(trigger, freq + (fdbk * sig[6]), 6);
	//DONE
	return sig[1]  + sig[2] + sig[3] + sig[4] + sig[5];
}
float alg25(int trigger, int note){
	
	sig[1] = opTrigger(trigger, freq, 1);
	sig[2] = opTrigger(trigger, freq, 2);
	sig[3] = opTrigger(trigger, freq, 3);
	sig[4] = opTrigger(trigger, freq + sig[6], 4);
	sig[5] = opTrigger(trigger, freq + sig[6], 5);
	sig[6] = opTrigger(trigger, freq + (sig[6] * fdbk), 6);
	//DONE
	return sig[1]  + sig[2] + sig[3] + sig[4] + sig[5];
}
float alg26(int trigger, int note){
	
	sig[1] = opTrigger(trigger, freq, 1);
	sig[2] = opTrigger(trigger, freq + sig[3], 2);
	sig[3] = opTrigger(trigger, freq, 3);
	sig[4] = opTrigger(trigger, freq + sig[5] + sig[6], 4);
	sig[5] = opTrigger(trigger, freq, 5);
	sig[6] = opTrigger(trigger, freq + (sig[6] * fdbk), 6);
	//DONE
	return sig[1]  + sig[2] + sig[4];
}
float alg27(int trigger, int note){

	sig[1] = opTrigger(trigger, freq, 1);
	sig[2] = opTrigger(trigger, freq, 2);
	sig[3] = opTrigger(trigger, freq + (sig[3] * fdbk), 3);
	sig[4] = opTrigger(trigger, freq + sig[5] + sig[6], 4);
	sig[5] = opTrigger(trigger, freq, 5);
	sig[6] = opTrigger(trigger, freq, 6);
	//DONE
	return sig[1]  + sig[2] + sig[4];
}
float alg28(int trigger, int note){
	//DONE
	sig[1] = opTrigger(trigger, freq, 1);
	sig[2] = opTrigger(trigger, freq, 2);
	sig[3] = opTrigger(trigger, freq + sig[4], 3);
	sig[4] = opTrigger(trigger, freq + sig[5], 4);
	sig[5] = opTrigger(trigger, freq + (fdbk * sig[5]), 5);
	sig[6] = opTrigger(trigger, freq, 6);
	
	return sig[1]  + sig[3] + sig[6];
}
float alg29(int trigger, int note){
	//DONE
	sig[1] = opTrigger(trigger, freq, 1);
	sig[2] = opTrigger(trigger, freq, 2);
	sig[3] = opTrigger(trigger, freq + sig[4], 3);
	sig[4] = opTrigger(trigger, freq, 4);
	sig[5] = opTrigger(trigger, freq + sig[6], 5);
	sig[6] = opTrigger(trigger, freq + (sig[6] * fdbk), 6);
	
	return sig[1]  + sig[2] + sig[3] + sig[5];
}
float alg30(int trigger, int note){
	//DONE
	sig[1] = opTrigger(trigger, freq, 1);
	sig[2] = opTrigger(trigger, freq, 2);
	sig[3] = opTrigger(trigger, freq + sig[4], 3);
	sig[4] = opTrigger(trigger, freq + sig[5], 4);
	sig[5] = opTrigger(trigger, freq + (sig[5] * fdbk), 5);
	sig[6] = opTrigger(trigger, freq, 6);
	
	return sig[1]  + sig[2] + sig[3] + sig[6];
}
float alg31(int trigger, int note){
	//DONE
	sig[1] = opTrigger(trigger, freq, 1);
	sig[2] = opTrigger(trigger, freq, 2);
	sig[3] = opTrigger(trigger, freq, 3);
	sig[4] = opTrigger(trigger, freq, 4);
	sig[5] = opTrigger(trigger, freq + sig[6], 5);
	sig[6] = opTrigger(trigger, freq + (sig[6]*fdbk), 6);
	
	return sig[1]  + sig[2] + sig[3] + sig[4] + sig[5];
}
float alg32(int trigger, int note){
	//DONE
	sig[1] = opTrigger(trigger, freq, 1);
	sig[2] = opTrigger(trigger, freq, 2);
	sig[3] = opTrigger(trigger, freq, 3);
	sig[4] = opTrigger(trigger, freq, 4);
	sig[5] = opTrigger(trigger, freq, 5);
	sig[6] = opTrigger(trigger, freq + (sig[6] * fdbk), 6);
	
	return sig[1]  + sig[2] + sig[3] + sig[4] + sig[5] + sig[6];
}

void algsInit(void){

	algs[1] = &alg1;
	algs[2] = &alg2;
	algs[3] = &alg3;
	algs[4] = &alg4;
	algs[5] = &alg5;
	algs[6] = &alg6;
	algs[7] = &alg7;
	algs[8] = &alg8;
	algs[9] = &alg9;
	algs[10] = &alg10;
	algs[11] = &alg11;
	algs[12] = &alg12;
	algs[13] = &alg13;
	algs[14] = &alg14;
	algs[15] = &alg15;
	algs[16] = &alg16;
	algs[17] = &alg1;
	algs[18] = &alg2;
	algs[19] = &alg3;
	algs[20] = &alg4;
	algs[21] = &alg5;
	algs[22] = &alg6;
	algs[23] = &alg7;
	algs[24] = &alg8;
	algs[25] = &alg9;
	algs[26] = &alg10;
	algs[27] = &alg11;
	algs[28] = &alg12;
	algs[29] = &alg13;
	algs[30] = &alg14;
	algs[31] = &alg15;
	algs[32] = &alg16;

}

void presetsInit(void){
	presets[1] = &preset1;
	presets[2] = &preset2;
	presets[3] = &preset3;
	//presets[4] = &preset4;
	//presets[5] = &preset5;
	//presets[6] = &preset6;

}