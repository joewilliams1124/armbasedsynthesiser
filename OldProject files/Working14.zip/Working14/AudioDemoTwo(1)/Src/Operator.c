#include "envelope.h"
#include "oscillator.h"
#include "operator.h"
#include "config.h"

//Define all instances of operator

//extern oscillator osc;
extern oscillator 		oscs[OPERATORS];
extern envelope 			envs[OPERATORS];
operator 							ops[OPERATORS];

//Initialise all the operators with some values
void opConnect(){
	generateSineTable();
	int n;
	for (n = 0; n < OPERATORS; n ++){
	//Ascociate operators with corresponding envelopes and oscillators
	ops[n].env = &envs[n];
	ops[n].osc = &oscs[n];
	}
}

void voxConnect(){
	for (int i = 1; i < 4; i ++){
	ops[i] = ops[i + 4];
	}
}

void opInit(int n){
	ops[n].modAmount = 0;
	ops[n].out = 0;
	ops[n].modIndex = 1;
	envInit(ops[n].env);
	oscInit(ops[n].osc);
}


//Set the values associated with the operator
void opSet(int n, float modIndex, float modAmount){
	ops[n].modIndex = modIndex;
	ops[n].modAmount = modAmount;
}

//Calculate the output of the operator, this function must be passed an operator and envelope.
void opOutput(float freq, int n){
	freq = freq * ops[n].modIndex;
	oscSetFreq(ops[n].osc, freq + ops[n].detune);
	ops[n].out = oscOutput(ops[n].osc) * envOutput(ops[n].env);
	ops[n].out = ops[n].out * ops[n].modAmount;
}
//Trigger the operator, this can be used with MIDI note on and off. 
//It's passed an int so that in future it can aid voice allocation. e.g 1 is vox 1 on, 3 is vox 2 on ect.
float opTrigger(int trigger, float freq, int n){
	
	float out;
	
	if (trigger == 1){
	envState(ops[n].env,1);
	opOutput(freq,n);
	}
	if (trigger == 0){
	envState(ops[n].env,0);
	opOutput(freq,n);	
	}

	return ops[n].out;
}

