#ifndef __SYNTH_H
#define __SYNTH_H

void synthInit();
void synthPreset(int patch);
float synthTrigger();

#endif