#include "oscillator.h"
#include "config.h"

int16_t SineTable[PBSIZE];

//Define all instances of oscillator
oscillator oscs[OPERATORS];


//Initialize an oscillator 
void oscInit(oscillator *osc){
	osc->amp = 10; //Scaled FM (9 hz)
	osc->freq = 261.6;
	osc->phase = 0;
	osc->out = 0;
	osc->phaseInc = 1;
	oscSetPhaseInc(osc);
}

void oscSetFreq(oscillator *osc, float f){
	osc->freq = f;
	oscSetPhaseInc(osc);
}

void oscSetAmp(oscillator *osc, float a){
	osc->amp = a;
}

//Work out the phase increment needed for the frequency specified
void oscSetPhaseInc(oscillator *osc){
	float phaseInc = SINELOOKUPSIZE * osc->freq / 44100;
	osc->phaseInc = phaseInc;
}

//Calculate the output sample from the oscillator
float oscOutput(oscillator *osc){
	if (osc->phase > SINELOOKUPSIZE) osc->phase -= SINELOOKUPSIZE;
	osc->phase += osc->phaseInc;
	osc->out = SineTable[(uint16_t)(osc->phase)] * osc->amp;
	return osc->out;
}

///// Set up the sine look-up table:
void generateSineTable(){
	for (int i = 0; i <= SINELOOKUPSIZE; i++) {
		float q = 32760 * sin(i * 2.0 * PI / SINELOOKUPSIZE);
		SineTable[i] = (int16_t)q;
	}
}
