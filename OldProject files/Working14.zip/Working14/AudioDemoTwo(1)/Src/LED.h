#ifndef __LED_H
#define __LED_H

#include "..\Drivers\Audio\stm32f4_discovery.h"

void LED_Dance(void);

#endif
