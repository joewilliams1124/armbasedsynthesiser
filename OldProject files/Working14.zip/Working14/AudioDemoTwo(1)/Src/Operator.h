#ifndef __operator_H
#define __operator_H

#include "stm32f4xx_hal.h"
#include <math.h>
#include "oscillator.h"
#include "envelope.h"

typedef struct
{
	float 	modIndex;	// should be <= 1 for normal sound output
	float	  modAmount;	// Hertz
	float   detune;
	float 	out;	// output sample
	oscillator *osc;
	envelope *env;
} operator;

void opConnect(void);

void voxConnect(void);

void opInit(int n);
	
void opOutput(float freq, int n);

void opSet(int n, float modIndex, float modAmount);

float opTrigger(int trigger,float freq, int n);

#endif


