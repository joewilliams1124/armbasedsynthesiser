#ifndef __CONFIG_H
#define __CONFIG_H

#define OPERATORS 12
#define PBSIZE 16384
//Define the number of values in the sine look up table, the more the smoother the sine wave. 
#define SINELOOKUPSIZE 8192
#define PI 3.1415926535897932384
#endif