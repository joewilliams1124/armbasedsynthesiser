#ifndef __envelope_H
#define __envelope_H

typedef struct
{
	float 	aTime;	
	float		aLevel;	
	float 	dTime;	
	float 	dLevel;	
	float 	sTime;
	float 	sLevel;
	float 	rTime;
	float 	rLevel;
	float aRate;
	float dRate;
	float sRate;
	float rRate;
	float coeff[4];
	int 	p1Time;
	int 	p2Time;
	int 	p3Time;
	int 	p4Time;
	float 	Count;
	char 		State;
	float   Out;
} envelope;

void envInit(envelope *env);

void envState(envelope *env, int trigger);

void envCalc(envelope *env);

float envOutput(envelope *env);

void envSet(envelope *env, float aTime, float aLevel, float dTime, float dLevel, float sTime, float sLevel, float rTime, float rLevel);

void envReset(void);

void envHold(void);

#endif

