#include <math.h>
#include "OutputMixer.h"

Mixer 		Mixer1;
float overshoot = 0;

//Scale the output of the operator down from 0 -1 then cast to correct type for audio buffer

uint16_t castOutput(float value, Mixer * Mixer1){
	//value = OOPS_softClip(value,20);
	value = value * Mixer1->scale;
	value = value / 10;
	Mixer1->outpt = (uint16_t)((int32_t)(value));
	value = Mixer1->outpt;
	return value;
}

//Write a compressor

float OOPS_softClip(float val, float thresh) 
{
	float x;
	
	if(val > thresh)
	{
			x = thresh / val;
			return (1.0f - x) * (1.0f - thresh) + thresh;
	}
	else if(val < -thresh)
	{
			x = -thresh / val;
			return -((1.0f - x) * (1.0f - thresh) + thresh);
	}
	else
	{
		return val;
	}
}

// Equaliser?

// Low pass filter??