#ifndef __CONTROL_H
#define __CONTROL_H

#include "envelope.h"
#include "operator.h"
#include "noteTable.h"
#include "Buttons.h"
#include "Envelope.h"
#include "OutputMixer.h"
#include "MIDI.h"

void MIDIConnect(void);

float scale127(int MIDIvalue, float max);

#endif
