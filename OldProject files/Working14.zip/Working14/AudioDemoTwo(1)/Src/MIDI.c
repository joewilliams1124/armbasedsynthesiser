#include "MIDI.h"
#include <stdbool.h>
#include "Envelope.h"
//I think clk overall is 168MHz//
//Tx = PC6	Rx = PC7/

int rByte;
int velocity = 0;
int byteNum = 0;

MIDImessage MIDI;

void midiInit(){
	MIDI.noteNum = 60;
  MIDI.trigger = 0;
	MIDI.velocity = 127;
	MIDI.vox = 1;
}


void readMIDI(int rByte){
	if (rByte > 127){
		MIDI.status = rByte;
		byteNum = 0;
	} else {
		MIDI.dataByte[byteNum] = rByte;
		byteNum = !byteNum; //Flips from 0 to 1.
	}
}

void resetEnv(){
	if (MIDI.trigger == 0){
	envReset();
	}
}

void processNote(void){
	if (MIDI.status == 0x90){ //Note On
		resetEnv();
		MIDI.trigger = 1;
		MIDI.noteNum = MIDI.dataByte[0];
		//MIDI.vox ++;
		//MIDI.velocity = MIDI.dataByte[1];
		if (MIDI.dataByte[1] == 0){
			MIDI.trigger = 0;
			//MIDI.vox --;
		}else{
			MIDI.velocity = MIDI.dataByte[1];
		}
	}
}

void processControlChange(void){
	if (MIDI.status >= 0xB0 && MIDI.status <= 0xBF){
		MIDI.ccData[MIDI.dataByte[0]] = MIDI.dataByte[1];
	//	int digit = MIDI.dataByte[0];	
		
	//	int i = digit - 10;
	//	char c = i +'0';
		
		//PB_LCD_WriteChar(c);
		
		}
	}


void test(){
	USART2->CR1 |= USART_CR1_RE; //YOU HAVE TO RUN IN HERE ELSE THE INTERRUPT MESSES UP
}

void USART2_IRQHandler(void){
	int rByte = PB_FTDI_Receive();
	readMIDI(rByte);
	processNote();
	processControlChange();
}

void PB_FTDI_Init(){
  // Start trying to use USART2 (which is connected to the FTDI module via PA2).
  const unsigned int RCC_APB1RSTR = RCC_BASE + 0x20;     // Address of reset register
  const unsigned int USART2_BIT_IN_RCC = RCC_APB1RSTR_USART2RST_Pos; // USART2 on bit 17
  
  RCC->APB1ENR |= RCC_APB1ENR_USART2EN; // Enable the UART2 clock
  
  // First, reset the UART then bring it out of reset:
  *(unsigned int*)RCC_APB1RSTR |= 1UL << USART2_BIT_IN_RCC;
  *(unsigned int*)RCC_APB1RSTR &= ~(1UL << USART2_BIT_IN_RCC);
  
  // Set up the UART as a 9600 baud UART which can transmit only.
  // The MIDI drivers used 32 << 4 to get 31.25 kbaud, so 9600 baud should be
  // 16 MHz / 16 / 104 = 9600.  That's less than 0.2% out, it might do...
  USART2->BRR = 0x511;
  USART2->CR1 = (1UL << 13) | (1UL << 3);
  
  // Turn clock to GPIOA on, set-up PA2 as an output, and configure PA3 to take 
  // input from USART2 (note you have to turn the clock on before writing to 
  // the register):
	
  RCC->AHB1ENR  |= RCC_AHB1ENR_GPIOAEN;         // Enable GPIOA clock  
  GPIOA->AFR[0] = (GPIOA->AFR[0] & 0xFFFFF0FF) | (0x7 << 8);
  unsigned int bit = 2;
  unsigned int bitMask = ~(3UL << 2*bit);
  GPIOA->MODER = (GPIOA->MODER & bitMask) | (2UL << 2*bit);  

  // Also set up PA3 as in AF mode, also with alternate function AF7:
  GPIOA->AFR[0] = (GPIOA->AFR[0] & 0xFFFF0FFF) | (0x7 << 12);
  bit = 3;
  bitMask = ~(3UL << 2*bit);
  GPIOA->MODER = (GPIOA->MODER & bitMask) | (2UL << 2*bit);
	
	USART2->CR1 |= USART_CR1_RXNEIE | USART_CR1_UE; //Enable RXNE interrupt
	
	NVIC_EnableIRQ(USART2_IRQn);
	
	midiInit();
	
}

void PB_FTDI_Wait_Until_Ready() {
  //unsigned int bReady = 0;
  //do {
  //  bReady = USART2->SR & (1UL << 7);
  //} while (!bReady);
	while (!(USART2->SR & USART_SR_TXE));
}

void PB_FTDI_Send(char *bytes, int howMany) {
  // Sends howMany bytes, starting at the address pointed to by
  // bytes, or until it reaches the end of the string (whichever
  // happens first).
  unsigned int next = 0;  
  while (next++ < howMany && *bytes) {
    PB_FTDI_Wait_Until_Ready();
    USART2->DR = *bytes++;
  }
}

void PB_FTDI_SendNewLine() {
  // Does what it says on the tin... sending a carriage return and new-line code:
  PB_FTDI_Wait_Until_Ready();
  USART2->DR = '\r';
  PB_FTDI_Wait_Until_Ready();
  USART2->DR = '\n';
}

int PB_FTDI_Receive() {
	// Returns the received character.  If there is no receive character in the 
	// receive buffer, it returns 1.
	USART2->CR1 |= USART_CR1_RE;
	int data = 0;
	if (USART2->SR & USART_SR_RXNE) data = USART2->DR;
	return data;
}
